<div class="profile_nav">
          <ul> 
             <li><a href="myads.php">My Ads</a></li>           
            <li><a href="mybooking.php">My Booking</a></li>
            <li><a href="logout.php">Sign Out</a></li>
          </ul>
        </div>
      </div> 